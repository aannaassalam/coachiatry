export const MAX_SIZE_FILE = 2000000;
export const CHART_HEIGHT = 400;

export const LEGEND_HEIGHT = 72;
export const HEADER = {
  H_MOBILE: 64,
  H_DESKTOP: 80,
  H_DESKTOP_OFFSET: 80 - 16
};

export const NAV = {
  WIDTH: 280
};
